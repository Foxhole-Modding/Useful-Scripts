# UnrealPak
## To unpack assets:
* Copy over the cyubeVR-WindowsNoEditor.pak file from the steamapps\command\cyubeVR\cyubeVR\Content\Paks folder to the CyubePaker folder.
* Drag the cyubeVR-WindowsNoEditor.pak file onto the _Unpack.bat file. A command window should open and run for 1-2 minutes.

## To repack your modified assets:
* Copy your Content folder into the Input folder.
* Drag the Input folder into the _Repack.bat file. A command window should open and run for a few seconds, depending on how many assets you have.

## To install your mod to the game:
* Copy the generated Input_P.pak file into the steamapps\command\cyubeVR\cyubeVR\Content\Paks folder. **Make sure that the filename is suffixed with _P, otherwise it won't be replaced by the game.**

*Tool put together by Buckminsterfullerene#6666.*